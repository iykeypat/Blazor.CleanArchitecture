﻿namespace Blazor.CleanArchitecture.Domain
{
    public class Class1
    {

    }
}
